create table flow_schema.flow_table
(
	sw_id varchar(45) references flow_schema.flow_table(node_id),
	src varchar(45) not null,
	dest varchar(45) not null,
	out_port real not null,
	prio real not null,
	h_timeout real not null,
	pkt_count real not null,
	byte_count real not null,
	duration real not null
);

create table flow_schema.wl_node_prop
(
	node_id varchar(45) primary key,
	ip_addr varchar(15) not null,
	mac_addr varchar(20) not null,
	_type varchar(45) not null,
	_position varchar(45) not null,
	_range real not null,
	sta_asso varchar(45) not null,
	ap_asso varchar(45) not null,
	ap_in_rng varchar(45) not null,
	_channel real not null,
	freq real not null,
	_mode varchar(45) not null,
	rssi real not null,
	tx_pwr real not null
);

create table flow_schema.wl_channel_prop
(
	channel_id varchar(45) references channel_map_tab(channel_id) on delete cascade,
	bandwidth real not null,
	distance real not null,
	pathloss real not null,
	latency real not null,
	delay real not null
);

create table flow_schema.channel_map_tab
(
	channel_id varchar(45) primary key,
	node_1 varchar(45) references wl_node_prop(node_id) on delete cascade,
	node_2 varchar(45) references wl_node_prop(node_id) on delete cascade  
);


-----------------------------------------------------------------------------------
--demo entry
-----------------------------------------------------------------------------------

insert into wl_node_prop values(
	'sta1','10.0.0.1','00:00:00:00:00:01','station','20,10,1',15,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'sta2','10.0.0.2','00:00:00:00:00:02','station','30,10,1',15,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'sta3','10.0.0.3','00:00:00:00:00:03','station','32,60,1',15,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'sta4','10.0.0.4','00:00:00:00:00:04','station','40,65,1',15,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'sta5','10.0.0.5','00:00:00:00:00:05','station','50,15,1',15,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'sta6','10.0.0.6','00:00:00:00:00:06','station','60,20,1',15,'na','na','na',11,2.4,'g',0,0
);

insert into wl_node_prop values(
	'ap1','na','na','ap','30,30,1',30,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'ap2','na','na','ap','37,50,1',30,'na','na','na',11,2.4,'g',0,0
);
insert into wl_node_prop values(
	'ap3','na','na','ap','45,30,1',15,'na','na','na',11,2.4,'g',0,0
);

insert into wl_channel_prop values('ch_u1_a1',1.51, 573.15, 9.266, 0 , 0);
insert into wl_channel_prop values('ch_u2_a1',14.99, 440.71, 3.326, 0 , 0);
insert into wl_channel_prop values('ch_u3_a2',0.86, 514.20, 276.7, 0 , 0);
insert into wl_channel_prop values('ch_u4_a2',28.00, 245.20, 1.347, 0 , 0);
insert into wl_channel_prop values('ch_u5_a5',5.22, 584.23, 575.7, 0 , 0);
insert into wl_channel_prop values('ch_u6_a2',42.91, 288.14, 0.001107, 0 , 0); 