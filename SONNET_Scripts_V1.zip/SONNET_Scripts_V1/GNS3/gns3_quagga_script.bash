apt -y update; apt -y install quagga nmap
cd /usr/share/doc/quagga/examples/
mkdir proto
cp *.sample proto
cd proto 
ls
mv babeld.conf.sample babeld.conf
mv bgpd.conf.sample bgpd.conf
mv isisd.conf.sample isisd.conf
mv ospf6d.conf.sample ospf6d.conf
mv ospfd.conf.sample ospfd.conf
mv pimd.conf.sample pimd.conf
mv ripd.conf.sample ripd.conf
mv ripngd.conf.sample ripngd.conf
mv vtysh.conf.sample vtysh.conf
mv zebra.conf.sample zebra.conf
clear
ll
cp *.conf /etc/quagga/
cd /etc/quagga/
nano daemons
/etc/init.d/quagga start

nmap localhost
#----------------------------------------------------
# IP interface config
#----------------------------------------------------
#Qga 1 
telnet localhost 2601
enable
	conf t
	int eth1
		ip address 10.0.13.1/24
		no shut
		exit
	int eth2
		ip address 10.0.12.1/24
		no shut
		exit
	int eth4
		ip address 192.168.1.1/24
		no shut
		exit
	exit
sh int 
sh ip route

#Qga 2
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.12.2/24
		no shut
		exit
	int eth2
		ip address 10.0.23.1/24
		no shut
		exit
	int eth3
		ip address 10.0.24.1/24
		no shut
		exit
	int eth4
		ip address 10.0.25.1/24
		no shut
		exit
	int eth5
		ip address 10.0.27.1/24
		no shut
		exit
	exit
sh int
sh ip route

#Qga3
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.13.2/24
		no shut
		exit
	int eth2
		ip address 10.0.23.2/24
		no shut
		exit
	int eth3
		ip address 10.0.35.1/24
		no shut
		exit
	int eth4
		ip address 192.168.3.1/24
		no shut
		exit
	exit
sh int
sh ip route

#Qga4
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.24.2/24
		no shut
		exit
	int eth2
		ip address 10.0.45.1/24
		no shut
		exit
	int eth3
		ip address 10.0.46.1/24
		no shut
		exit
	int eth4
		ip address 10.0.47.1/24
		no shut
		exit
	exit
sh int
sh ip route

#Qga5
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.25.2/24
		no shut
		exit
	int eth2
		ip address 10.0.45.2/24
		no shut
		exit
	int eth3
		ip address 10.0.56.1/24
		no shut
		exit
	int eth4
		ip address 10.0.35.2/24
		no shut
		exit
	exit
sh int
sh ip route

#Qga6
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.46.2/24
		no shut
		exit
	int eth2
		ip address 10.0.56.2/24
		no shut
		exit
	int eth4
		ip address 192.168.6.1/24
		no shut
		exit
	exit
sh int
sh ip route

#Qga7
telnet localhost 2601
enable 
	conf t
	int eth1
		ip address 10.0.47.2/24
		no shut
		exit
	int eth2
		ip address 10.0.27.2/24
		no shut
		exit
	int eth4
		ip address 192.168.7.1/24
		no shut
		exit
	exit
sh int
sh ip route
#----------------------------------------------------
# RIP Configuration
#----------------------------------------------------
#Qga1
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.12.0/24
		network 10.0.13.0/24
		network 192.168.1.0/24
		exit
	exit
sh ip rip

#Qga2
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.12.0/24
		network 10.0.23.0/24
		network 10.0.24.0/24
		network 10.0.25.0/24
		network 10.0.27.0/24
		exit
	exit
sh ip rip

#Qga3
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.13.0/24
		network 10.0.23.0/24
		network 10.0.25.0/24
		network 192.168.3.0/24
		exit
	exit
sh ip rip

#Qga4
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.24.0/24
		network 10.0.45.0/24
		network 10.0.46.0/24
		network 10.0.47.0/24
		exit
	exit
sh ip rip 

#Qga5
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.25.0/24
		network 10.0.35.0/24
		network 10.0.45.0/24
		network 10.0.56.0/24
		exit
	exit
sh ip rip 

#Qga6
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.46.0/24
		network 10.0.56.0/24
		network 192.168.6.0/24
		exit
	exit
sh ip rip

#Qga7
telnet localhost 2602
enable
	conf t
	router rip
		ver 2
		network 10.0.27.0/24
		network 10.0.47.0/24
		network 192.168.7.0/24
		exit
	exit
sh ip rip	

#----------------------------------------------------
# OSPF Configuration
#----------------------------------------------------
#Qga1
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.12.0/24 area 0
	 	network 10.0.13.0/24 area 0
		network 192.168.1.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga2
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.12.0/24 area 0
		network 10.0.23.0/24 area 0
		network 10.0.24.0/24 area 0
		network 10.0.25.0/24 area 0
		network 10.0.27.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga3
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.13.0/24 area 0
		network 10.0.23.0/24 area 0
		network 10.0.25.0/24 area 0
		network 192.168.3.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga4
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.24.0/24 area 0
		network 10.0.45.0/24 area 0
		network 10.0.46.0/24 area 0
		network 10.0.47.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga5
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.25.0/24 area 0
		network 10.0.35.0/24 area 0
		network 10.0.45.0/24 area 0
		network 10.0.56.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga6
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.46.0/24 area 0
		network 10.0.56.0/24 area 0
		network 192.168.6.0/24 area 0
		exit
	exit
sh ip ospf route

#Qga7
telnet localhost 2604
enable
	conf t
	router ospf
		network 10.0.27.0/24 area 0
		network 10.0.47.0/24 area 0
		network 192.168.7.0/24 area 0
		exit
	exit
sh ip ospf route