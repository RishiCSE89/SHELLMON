import pymysql
import time
import os

db_conn=None
db_cur=None

def db_connect(host,port,uname,passwd,schema):
    global db_conn
    db_conn=pymysql.connect(host=host,port=int(port),user=uname,passwd=passwd,db=schema)
    

    
def db_clear(host,port,uname,passwd,schema):
    db_connect(host,port,uname,passwd,schema)
    qstr="delete from flow_schema.local_info"
    global  db_cur
    db_cur = db_conn.cursor()
    db_cur.execute(qstr)
    db_cur.close()
    db_conn.close()

def fetch(host,port,uname,passwd,schema):
    db_connect(host,port,uname,passwd,schema)
    qstr="select    ip, mac, avg(z_val) " \
         "from      flow_schema.local_info " \
         "group by  ip " \
         "order by  ip"
   
    global  db_cur
    db_cur = db_conn.cursor()
    db_cur.execute(qstr)
    os.system('cls')
    for row in db_cur:
        print(row)
    db_cur.close()
    db_conn.close()    

if __name__ == '__main__':
    host=input('Enter MySQL server IP address : ')
    port=input('Enter poer number (default 3306) : ')
    uname=input('Enter username : ')
    passwd=input('Enter passowd : ')
    schema=input('Enter schema name : ')

    choice=input('\n\n\t\t Do you want to reset the database ? (y/n)...')
    if choice == 'y':
        db_clear(host,port,uname,passwd,schema)
    while True:
        fetch(host,port,uname,passwd,schema)
        time.sleep(3)

        
