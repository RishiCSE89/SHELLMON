echo 'updating repository...'
	apt -y update > /dev/null
echo 'repo update done!'

echo 'preparing...'
apt -y install figlet > /dev/null 
figlet ShellMon - by - Saptarshi Ghosh
echo 'press any key to continue...'
read x 
echo 'Installing python...'
	echo 'python3...'
		apt -y install python3  > /dev/null
	echo 'done!'
	
	echo 'pip3'
		apt -y install python3-pip > /dev/null
	echo 'done!'
	
	echo 'tkinter3'
		apt -y install python3-tk > /dev/null
	echo 'done'
echo 'Python installation done!'

echo 'Updating pip3...'
	pip3 install --upgrade pip
echo 'pip update done!'

echo 'Installing python libraries for shellmon'

	echo 'matplotlib...'
		pip3 install matplotlib > /dev/null
	echo 'done!'

	echo 'drawnow...' 
		pip3 install drawnow > /dev/null
	echo 'done!'

	echo 'psutil...'
		pip3 install psutil  > /dev/null
	echo 'done!'
	
	echo 'pymysql...'
		pip3 install pymysql  > /dev/null
	echo 'done!'
echo 'libraries installation done! '