#!/usr/bin/python

'This example creates a simple network topology with 1 AP and 2 stations'

import sys

from mininet.node import Controller, RemoteController
from mininet.log import setLogLevel, info
from mininet.wifi.node import OVSKernelAP
from mininet.wifi.cli import CLI_wifi
from mininet.wifi.net import Mininet_wifi

'''------------------------------------------------------------------------------------------------'''
import pymysql

db_conn = None
db_cur = None

lst_node = []
lst_channel = []


class node:
    def __init__(self, n_id, ip, mac, typ, pos, rng, sta_asso, ap_asso, ap_in_rng, chan, freq, mode, rssi, tx_pwr):
        self.node_id = n_id  # str
        self.ip_addr = ip  # str
        self.mac_addr = mac  # str
        self.type = typ  # str
        self.position = pos  # str
        self.range = rng  # flt
        self.sta_asso = sta_asso  # str
        self.ap_asso = ap_asso  # str
        self.ap_in_rng = ap_in_rng  # str
        self.channel = chan  # flt
        self.freq = freq  # flt
        self.mode = mode  # str
        self.rssi = rssi  # flt
        self.tx_pwr = tx_pwr  # flt

    def get_node_prop(self):
        node_prop = [self.node_id, self.ip_addr, self.mac_addr, self.type, \
                     self.position, self.range, self.sta_asso, self.ap_asso, \
                     self.ap_in_rng, self.channel, self.freq, self.mode, \
                     self.rssi, self.tx_pwr
                     ]
        return node_prop


class channel:
    def __init__(self, c_id, bw, dist, p_loss, lat, delay):
        self.channel_id = c_id
        self.bandwidth = bw
        self.distance = dist
        self.pathloss = p_loss
        self.latency = lat
        self.delay = delay

    def get_channel_prop(self):
        channel_prop = [self.channel_id, \
                        self.bandwidth, \
                        self.distance, \
                        self.pathloss, \
                        self.latency, \
                        self.delay
                        ]
        return channel_prop


def mysql_conn(host, un, pw, db):
    global db_conn
    db_conn = pymysql.connect(host=host, user=un, passwd=pw, db=db)
    global db_cur
    db_cur = db_conn.cursor(pymysql.cursors.DictCursor)


def populate_lst_node():
    db_cur.execute("select * from wl_node_prop")
    for row in db_cur:
        # print(row)

        lst_node.append(
            node(
                str(row['node_id']), \
                str(row['ip_addr']), \
                str(row['mac_addr']), \
                str(row['_type']), \
                str(row['_position']), \
                str(row['_range']), \
                str(row['sta_asso']), \
                str(row['ap_asso']), \
                str(row['ap_in_rng']), \
                str(row['_channel']), \
                str(row['freq']), \
                str(row['_mode']), \
                str(row['rssi']), \
                str(row['tx_pwr'])
            )
        )



def populate_lst_channel():
    db_cur.execute("select * from wl_channel_prop")
    for row in db_cur:
        lst_channel.append(
            channel(
                str(row['channel_id']), \
                str(row['bandwidth']), \
                str(row['distance']), \
                str(row['pathloss']), \
                str(row['latency']), \
                str(row['delay'])
            )
        )


def lst_node_print():
    for n_idx in range(1, len(lst_node)):
        print(lst_node[n_idx].get_node_prop())


def lst_channel_print():
    for c_idx in range(1, len(lst_channel)):
        print(lst_channel[c_idx].get_channel_prop())


def mysql_fetch_main():
    host = '136.148.246.14'  # str(input('enter host_ip '))
    mysql_conn(host, 'rishi', 'password', 'flow_schema')
    populate_lst_node()
    populate_lst_channel()
    lst_node_print()
    lst_channel_print()


'''---------------------------------------------------------------------------------------'''

lst_ap = []
lst_sta = []


# 'sta1', mac='00:00:00:00:00:01', ip='10.0.0.4/24', position='20,10,0'
def add_station(net, sta_entry):
    sta = net.addStation(
        name=sta_entry[0], \
        ip=sta_entry[1], \
        mac=sta_entry[2], \
        position=sta_entry[4]
    )
    return sta


# 'ap1', ssid='ap1_ssid', mode='g', channel='1', position='30,30,0')
def add_ap(net, ap_entry):
    ap = net.addAccessPoint(
        name=ap_entry[0], \
        ssid=ap_entry[0] + '_ssid', \
        position=ap_entry[4], \
        channel='1',  # int(float(ap_entry[9])), \
        mode=ap_entry[11]
    )
    return ap

def alter_range():
    for sta in lst_sta:
        intf_name=str(sta)+'-wlan0'
        sta.setRange(15,intf=intf_name)

    for ap in lst_ap:
        k=0
        for host_asso in ap.params['associatedStations']:
            intf_name = str(ap) + '-wlan' + str(k)
            ap.setRange(50,intf=intf_name)

def fill_feed_back():
    for sta in lst_sta:
        sta_name=str(sta)
        rssi=sta.params['rssi']
        tx_pwr=sta.params['txpower']
        freq=sta.params['frequency']
        qstr="update flow_schema.wl_node_prop set " \
             "      freq="+ str(freq[0]) + ", " \
             "      rssi="+ str(rssi[0]) + ", " \
             "      tx_pwr=" + str(tx_pwr[0]) + " " \
             "where node_id= '" + str(sta_name) + "'"
        db_cur.execute(qstr)
        db_conn.commit()


def topology(isVirtual):
    "Create a network."
    net = Mininet_wifi(topo=None,
                       build=False,
                       ipBase='10.0.0.0/24')

    info('*** adding controlelr \n')
    c0 = net.addController(name='c0',
                           controller=RemoteController,
                           ip='192.168.204.135',
                           protocol='tcp',
                           port=6633)

    info("*** Creating nodes\n")
    info('*** Adding hosts...\n')


    info('*** Adding stations...\n')

    for i in range(0, len(lst_node)):
        node_prop = lst_node[i].get_node_prop()

        if node_prop[3] == 'station':
            info('*** Adding stations...' + node_prop[0] + '\n')
            lst_sta.append(add_station(net, node_prop))

        elif node_prop[3] == 'ap':
            info('*** Adding Accesspoint...' + node_prop[0] + '\n')
            lst_ap.append(add_ap(net, node_prop))

    info("*** Configuring wifi nodes\n")
    net.configureWifiNodes()

    info("*** Associating Stations\n")

    net.addLink(lst_ap[0], lst_sta[0])
    net.addLink(lst_ap[0], lst_sta[1])
    net.addLink(lst_ap[1], lst_sta[2])
    net.addLink(lst_ap[1], lst_sta[3])
    net.addLink(lst_ap[2], lst_sta[4])
    net.addLink(lst_ap[2], lst_sta[5])

    net.addLink(lst_ap[0], lst_ap[1])
    net.addLink(lst_ap[1], lst_ap[2])
    net.addLink(lst_ap[2], lst_ap[0])

    alter_range()

    net.plotGraph(max_x=100, max_y=100)
    net.plotGraph(max_x=100, max_y=100, max_z=50)

    info("*** Starting network\n")
    net.build()
    c0.start()
    for i in range(0, len(lst_ap)):
        lst_ap[i].start([c0])

    fill_feed_back()

    print('*** Running CLI \n')
    CLI_wifi(net)
    net.stop()


if __name__ == '__main__':
    mysql_fetch_main()
    setLogLevel('info')
    isVirtual = True if '-v' in sys.argv else False
    topology(isVirtual)
